Historical context only. AGENTS.md is the current project authority.
Some archived deadlines and scope proposals are superseded.
